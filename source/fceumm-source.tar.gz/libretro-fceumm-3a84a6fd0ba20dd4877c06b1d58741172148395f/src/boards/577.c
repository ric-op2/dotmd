/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2025 NewRisingSun
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"
#include "asic_latch.h"

static uint8_t pad;

static DECLFR (readOB) {
	return X.DB;
}

static void sync () {
	setprg16(0x8000, Latch_address);
	setprg16(0xC000, Latch_address);
	SetReadHandler(0x8000, 0xFFFF, Latch_address &pad &0x30? readOB: CartBR);
	setchr8(Latch_address >>1);
}

static void power () {
	pad = 0;
	Latch_power();
}

static void reset () {
	pad += 0x10;
	Latch_clear();
}

void Mapper577_Init (CartInfo *info) {
	Latch_init(info, sync, 0x8000, 0xFFFF, NULL);
	info->Power = power;
	info->Reset = reset;
	AddExState(&pad, 1, 0, "DIPS");
}
