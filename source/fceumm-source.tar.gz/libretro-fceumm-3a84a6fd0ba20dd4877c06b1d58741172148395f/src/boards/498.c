/* FCEUmm - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2020
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 *
 */

#include "mapinc.h"
#include "asic_mmc1.h"

static uint8_t reg;

static void sync () {
	if (reg &0x20)
		MMC1_syncPRG(0x07, reg >>1 &0x20 | reg &0x18);
	else
	if (reg &0x05)
		setprg32(0x8000, reg >>1);
	else {
		setprg16(0x8000, reg);
		setprg16(0xC000, reg);
	}
	MMC1_syncCHR(0x1F, reg <<1 &0x80 | reg <<2 &0x60);
	MMC1_syncMirror();
}

static DECLFW (writeReg) {
	reg = A &0xFF;
	sync();
}

static void reset () {
	reg = 0;
	MMC1_clear();
}

static void power () {
	reg = 0;
	MMC1_power();
}

void Mapper498_Init (CartInfo *info) {
	MMC1_init(info, sync, MMC1_TYPE_MMC1A, NULL, NULL, NULL, writeReg);
	info->Power = power;
	info->Reset = reset;
	AddExState(&reg, 1, 0, "EXPR");
}
