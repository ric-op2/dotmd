/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2025 NewRisingSun
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#ifndef _ASIC_MMC2AND4_H
#define _ASIC_MMC2AND4_H

void MMC24_syncWRAM (int);
void MMC2_syncPRG (int, int);
void MMC4_syncPRG (int, int);
void MMC24_syncCHR (int, int);
void MMC24_syncMirror(void);
DECLFW (MMC24_write);
void MMC24_clear(void);
void MMC24_power(void);
void MMC24_restore (int);
void MMC24_addExState(void);
void MMC24_activate (uint8_t, void (*)());
void MMC24_init (CartInfo *, void (*)());

#endif
